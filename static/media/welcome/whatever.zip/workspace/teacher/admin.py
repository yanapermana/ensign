from django.contrib import admin
from teacher.models import Teacher, Problem, Support, Evaluation
# Register your models here.
admin.site.register(Teacher)
admin.site.register(Problem)
admin.site.register(Support)
admin.site.register(Evaluation)